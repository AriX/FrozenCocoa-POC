/*
 * Copyright (c) 2011 Dmitry Skiba
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#if !defined(__COREFOUNDATION_CFALLOCATOR__)
#define __COREFOUNDATION_CFALLOCATOR__ 1

#if defined(__cplusplus)
extern "C" {
#endif

/* Allocator API
 *
 * Most of the time when specifying an allocator to Create functions, the NULL
 * argument indicates "use the default"; this is the same as using kCFAllocatorDefault
 * or the return value from CFAllocatorGetDefault().  This assures that you will use
 * the allocator in effect at that time.
 *
 * You should rarely use kCFAllocatorSystemDefault, the default default allocator.
 */

/* This is a synonym for NULL, if you'd rather use a named constant. */
CF_EXPORT
const CFAllocatorRef kCFAllocatorDefault;

/* Default system allocator; you rarely need to use this. */
CF_EXPORT
const CFAllocatorRef kCFAllocatorSystemDefault;

/* This allocator uses malloc(), realloc(), and free(). This should not be
 * generally used; stick to kCFAllocatorDefault whenever possible. This
 * allocator is useful as the "bytesDeallocator" in CFData or
 * "contentsDeallocator" in CFString where the memory was obtained as a
 * result of malloc() type functions.
 */
CF_EXPORT
const CFAllocatorRef kCFAllocatorMalloc;

/* This allocator explicitly uses the default malloc zone, returned by
 * malloc_default_zone(). It should only be used when an object is
 * safe to be allocated in non-scanned memory.
 */
CF_EXPORT
const CFAllocatorRef kCFAllocatorMallocZone;

/* Null allocator which does nothing and allocates no memory. This allocator
 * is useful as the "bytesDeallocator" in CFData or "contentsDeallocator"
 * in CFString where the memory should not be freed.
 */
CF_EXPORT
const CFAllocatorRef kCFAllocatorNull;

/* Special allocator argument to CFAllocatorCreate() which means
 * "use the functions given in the context to allocate the allocator
 * itself as well".
 */
CF_EXPORT
const CFAllocatorRef kCFAllocatorUseContext;

typedef const void* (*CFAllocatorRetainCallBack)(const void* info);
typedef void (*CFAllocatorReleaseCallBack)(const void* info);
typedef CFStringRef (*CFAllocatorCopyDescriptionCallBack)(const void* info);
typedef void* (*CFAllocatorAllocateCallBack)(CFIndex allocSize, CFOptionFlags hint, void* info);
typedef void* (*CFAllocatorReallocateCallBack)(void* ptr, CFIndex newsize, CFOptionFlags hint, void* info);
typedef void (*CFAllocatorDeallocateCallBack)(void* ptr, void* info);
typedef CFIndex (*CFAllocatorPreferredSizeCallBack)(CFIndex size, CFOptionFlags hint, void* info);

typedef struct {
    CFIndex version;
    void* info;
    CFAllocatorRetainCallBack retain;
    CFAllocatorReleaseCallBack release;
    CFAllocatorCopyDescriptionCallBack copyDescription;
    CFAllocatorAllocateCallBack allocate;
    CFAllocatorReallocateCallBack reallocate;
    CFAllocatorDeallocateCallBack deallocate;
    CFAllocatorPreferredSizeCallBack preferredSize;
} CFAllocatorContext;

CF_EXPORT
CFTypeID CFAllocatorGetTypeID(void);

/*
 * CFAllocatorSetDefault() sets the allocator that is used in the current
 * thread whenever NULL is specified as an allocator argument. This means
 * that most, if not all allocations will go through this allocator. It
 * also means that any allocator set as the default needs to be ready to
 * deal with arbitrary memory allocation requests; in addition, the size
 * and number of requests will change between releases.
 *
 * An allocator set as the default will never be released, even if later
 * another allocator replaces it as the default. Not only is it impractical
 * for it to be released (as there might be caches created under the covers
 * that refer to the allocator), in general it's also safer and more
 * efficient to keep it around.
 *
 * If you wish to use a custom allocator in a context, it's best to provide
 * it as the argument to the various creation functions rather than setting
 * it as the default. Setting the default allocator is not encouraged.
 *
 * If you do set an allocator as the default, either do it for all time in
 * your app, or do it in a nested fashion (by restoring the previous allocator
 * when you exit your context). The latter might be appropriate for plug-ins
 * or libraries that wish to set the default allocator.
 */
CF_EXPORT
void CFAllocatorSetDefault(CFAllocatorRef allocator);

CF_EXPORT
CFAllocatorRef CFAllocatorGetDefault(void);

CF_EXPORT
CFAllocatorRef CFAllocatorCreate(CFAllocatorRef allocator, CFAllocatorContext* context);

CF_EXPORT
void* CFAllocatorAllocate(CFAllocatorRef allocator, CFIndex size, CFOptionFlags hint);

CF_EXPORT
void* CFAllocatorReallocate(CFAllocatorRef allocator, void* ptr, CFIndex newsize, CFOptionFlags hint);

CF_EXPORT
void CFAllocatorDeallocate(CFAllocatorRef allocator, void* ptr);

CF_EXPORT
CFIndex CFAllocatorGetPreferredSizeForSize(CFAllocatorRef allocator, CFIndex size, CFOptionFlags hint);

CF_EXPORT
void CFAllocatorGetContext(CFAllocatorRef allocator, CFAllocatorContext* context);

#if defined(__cplusplus)
}
#endif

#endif /* ! __COREFOUNDATION_CFALLOCATOR__ */
