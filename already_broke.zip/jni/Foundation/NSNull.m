/*
 * Copyright (C) 2011 Dmitry Skiba
 * Copyright (c) 2006-2007 Christopher J. W. Lloyd
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

#import <Foundation/NSNull.h>
#import <Foundation/NSString.h>
#import <CoreFoundation/CFBase.h>

@class NSCoder;

/*
 * NSNull
 */

@implementation NSNull

+(NSNull*)null {
    return (NSNull*)kCFNull;
}

+(id)allocWithZone:(NSZone*)zone {
    return [self null];
}

-(id)init {
    return self;
}

-(id)copyWithZone:(NSZone*)zone {
    return self;
}

-(id)initWithCoder:(NSCoder*)coder {
    return Nil;
}

-(void)encodeWithCoder:(NSCoder*)coder {
}

-(void)dealloc {
    return;
    [super dealloc];
}

-(NSString*)description {
    return @"<null>";
}

-(id)autorelease {
    return self;
}

-(id)retain {
    return self;
}

-(void)release {
}

-(NSUInteger)retainCount {
    return NSUIntegerMax;
}

-(CFTypeID)_cfTypeID {
    return CFNullGetTypeID();
}

@end
